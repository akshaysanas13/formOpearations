import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Registration from "./Components/Registration";
import Login from "./Components/Login";
import Userdata from "./Components/Userdata";
import NavBar from "./Components/NavBar";
import Home from "./Components/Home";

function App() {
  return <div>
     <BrowserRouter>
     <NavBar/>
      <Routes>
        <Route path="/register" element={<Registration/>}/>
        <Route path="/home" element={<Home/>}/>
        <Route path="/login" element={<Login/>}/>
      </Routes>
        
     </BrowserRouter>
  </div>;
}

export default App;
