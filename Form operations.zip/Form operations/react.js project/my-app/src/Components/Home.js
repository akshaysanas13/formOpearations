import React from "react";
import "../home.css";
import { Link } from "react-router-dom";
const Home = () => {
  return (
    <div className="slogenParent d-flex align-items-center justify-content-center">
      <div className="text-center">
        <h1 className="slogenHeader">Welcome to Audilytics Solutions</h1>
        <h4 className="slogen">
          "Nurturing Innovation, Harvesting Excellence"
        </h4>
        <div className="flex mt-3">
          <Link to="/login">
            {"  "}
            <button className="login"> Login</button>
          </Link>
          <Link to="/register">
            {"  "}
            <button className="register"> Register</button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
