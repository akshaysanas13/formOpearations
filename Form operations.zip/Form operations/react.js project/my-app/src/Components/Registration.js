import React, { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { format } from "date-fns";
import '../login.css'
import '../registration.css'

const validationSchema = Yup.object().shape({
  username: Yup.string()
    .min(4, "Username must be at least 4 characters long")
    .test("username", "Username already exists", async (value) => {
      try {
        const response = await axios.get(
          `http://localhost:5000/api/checkUsername?username=${value}`
        );
        return !response.data.exists;
      } catch (error) {
        console.error("Error:", error);
        return false;
      }
    })
    .required("Username is required"),
  password: Yup.string()
    .min(7, "Password must be at least 7 characters long")
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/,
      "Password must contain at least one uppercase, one lowercase, one special character, and one number"
    )
    .required("Password is required"),
  firstName: Yup.string()
    .min(3, "First name must be at least 3 characters long")
    .matches(/^[a-zA-Z]+$/, "First name must only contain letters")
    .required("First name is required"),

  lastName: Yup.string()
    .min(3, "Last name must be at least 3 characters long")
    .matches(/^[a-zA-Z]+$/, "Last name must only contain letters")
    .required("Last name is required"),
  birthDate: Yup.date().required("Birth Date is required"),
  contactNumber: Yup.string()
    .matches(
      /^[6-9]\d{9}$/,
      "Contact number must be a 10-digit number starting with 6, 7, 8, or 9"
    )
    .required("Contact number is required"),
  address: Yup.string().required("Address is required"),
});
// console.log(firstName);
const Registration = () => {
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");

  const formik = useFormik({
    initialValues: {
      username: "",
      password: "",
      firstName: "",
      lastName: "",
      birthDate: "",
      contactNumber: "",
      address: "",
    },
    validationSchema,
    onSubmit: async (values) => {
      // console.log(values)
      setSubmitting(true);
      const username = document.getElementById("username").value;
      const password = document.getElementById("password").value;
      const firstName = document.getElementById("firstName").value;
      const lastName = document.getElementById("lastName").value;
      const birthDate = document.getElementById("birthDate").value;
      const contactNumber = document.getElementById("contactNumber").value;
      const address = document.getElementById("address").value;

      const object = {
        username: username,
        password: password,
        first_name: firstName,
        last_name: lastName,
        birth_date: birthDate,
        address: address,
        contact_number: contactNumber,
      };
      // console.log(object)
      try {
        // Make an API call to send the form data to the server
        await axios.post("http://localhost:5000/api/submit", object);
        console.log(object.data);

        // Reset the form on successful submission
        formik.resetForm();

        // Show success message
        alert("Account generated successfully");
      } catch (error) {
        console.log("Error:", error);
      }

      setSubmitting(false);
    },
  });

  return (
    <div className="regiImage p-3">
    <form
      onSubmit={formik.handleSubmit}
      className=" ms-5 p-3 col-6 flex justify-content-center border border-2 
      rounded bg-light-subtle"
    >
      {formError && <div>{formError}</div>}
      <div >
        <label htmlFor="username" className="col-form-label">
          Username:
        </label>
        <input
          type="text"
          id="username"
          name="username"
          value={formik.values.username}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          className="form-control "
        />
        {formik.touched.username &&
          formik.errors.username &&
          formik.submitCount > 0 && (
            <div className="error">{formik.errors.username}</div>
          )}
      </div>

      <div>
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          name="password"
          value={formik.values.password}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          className="form-control"
        />
        {formik.touched.password &&
          formik.errors.password &&
          formik.submitCount > 0 && (
            <div className="error">{formik.errors.password}</div>
          )}
      </div>

      <div className="row">
        <div className="col">
          <label htmlFor="firstName">First Name:</label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            value={formik.values.firstName}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
          />
          {formik.touched.firstName &&
            formik.errors.firstName &&
            formik.submitCount > 0 && (
              <div className="error">{formik.errors.firstName}</div>
            )}
        </div>
        <div className="col">
          <label htmlFor="lastName">Last Name:</label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            value={formik.values.lastName}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
          />
          {formik.touched.lastName &&
            formik.errors.lastName &&
            formik.submitCount > 0 && (
              <div className="error">{formik.errors.lastName}</div>
            )}
        </div>
      </div>
      <div>
        <label htmlFor="contactNumber">Birth date:</label>
        <input
          type="date"
          id="birthDate"
          name="birthDate"
          value={formik.values.birthDate}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          className="form-control"
        />
        {formik.touched.birthDate &&
          formik.errors.birthDate &&
          formik.submitCount > 0 && (
            <div className="error">{formik.errors.birthDate}</div>
          )}
      </div>
      <div>
        <label htmlFor="contactNumber">Contact Number:</label>
        <input
          type="text"
          id="contactNumber"
          name="contactNumber"
          value={formik.values.contactNumber}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          className="form-control"
        />
        {formik.touched.contactNumber &&
          formik.errors.contactNumber &&
          formik.submitCount > 0 && (
            <div className="error">{formik.errors.contactNumber}</div>
          )}
      </div>

      <div>
        <label htmlFor="address">Address:</label>
        <textarea
          id="address"
          name="address"
          value={formik.values.address}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          className="form-control"
        />
        {formik.touched.address &&
          formik.errors.address &&
          formik.submitCount > 0 && (
            <div className="error">{formik.errors.address}</div>
          )}
      </div>

      <button
        type="submit"
        disabled={submitting}
        className="btn btn-success mt-2 p-2"
      >
        Submit
      </button>
       
    </form>
    </div>
  );
};

export default Registration;
