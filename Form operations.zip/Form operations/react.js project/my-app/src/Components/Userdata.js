import React from 'react'

const Userdata = () => {
  return (
    <div>Userdata</div>
  )
}

export default Userdata