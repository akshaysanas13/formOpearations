import React, { useState, useEffect } from "react";
import axios from "axios";
import '../login.css'

const Login = () => {
  const [userName, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [userDetails, setUserDetails] = useState(null);
  const [isLoginDisabled, setIsLoginDisabled] = useState(false);
  const [currentTime, setCurrentTime] = useState("");

  useEffect(() => {
    // Update the current time every second
    const intervalId = setInterval(() => {
      const now = new Date();
      const formattedTime = now.toLocaleTimeString();
      setCurrentTime(formattedTime);
    }, 1000);
    // Clear the interval on component unmount
    return () => clearInterval(intervalId);
  }, []);

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleLogin = async (event) => {
    event.preventDefault();
    console.log(userName);
    try {
      const response = await axios.get(
        `http://localhost:5000/api/user?username=${userName}`
      );

      const user = response.data;

      console.log(user.username);
      // Compare entered username and password with the database values
      if (user.username === userName && user.password === password) {
        // Successful login
        setLoginError("");
        alert("login successful");
        // Store user details
        setUserDetails(user);
        // Disable the login button
        setIsLoginDisabled(true);
      } else {
        // Invalid login credentials
        setLoginError("Invalid username or password");
        // Clear user details
        setUserDetails(null);
        // Enable the login button
        setIsLoginDisabled(false);
      }
    } catch (error) {
      setLoginError("Invalid username or password");
      console.error("Error:", error);
    }
  };

  return (
    <div className="image">
      <div className="container-fluid shadow col-6 mt-4 rounded">
        <div className="p-2 row rounded d-flex justify-content-center">
          <form onSubmit={handleLogin}>
            <div className="col">
              <label htmlFor="username" className="label_color">Username:</label>
              <input
                type="text"
                id="username"
                value={userName}
                onChange={handleUsernameChange}
                className="form-control "
              />
            </div>
            <div className="col">
              <label htmlFor="password" className="label_color">Password:</label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={handlePasswordChange}
                className="form-control"
              />
            </div>
            <div className="col">
              {loginError && <div className="error">{loginError}</div>}
              <button
                type="submit"
                disabled={isLoginDisabled}
                className="btn btn-success mt-2"
              >
                Login
              </button>
            </div>
          </form>
        </div>
      </div>

      {userDetails && (
        <div className="d-flex p-5">
          <div className="container">
            <h2 className="d-flex justify-content-center">User Information:</h2>
            <table className="table shadow  bg-body rounded">
              <thead>
                <tr>
                  <th scope="col">Your name</th>
                  <th scope="col">Contact number</th>
                  <th scope="col">Birth date</th>
                  <th scope="col">Time</th>
                  <th scope="col">Address</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    {userDetails.first_name + " "}
                    {userDetails.last_name}
                  </td>
                  <td>{userDetails.contact_number}</td>
                  <td>
                    {new Date(userDetails.birth_date).toLocaleDateString(
                      "en-GB"
                    )}
                  </td>
                  <td>{currentTime}</td>
                  <td>{userDetails.address}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Login;
