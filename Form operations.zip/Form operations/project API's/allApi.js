const Express = require("express");
const con = require("./server");
const app = Express();
const cors = require("cors");
app.use(cors());

const bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/getuserdata", (req, res) => {
  con.query("select * from users", function (err, result) {
    if (err) {
      res.send("error");
    } else {
      res.send(result);
    }
  });
});

app.get("/api/checkUsername", (req, res) => {
    const { username } = req.query;
    con.query("SELECT * FROM users WHERE username = ?", [username], (err, result) => {
      if (err) {
        console.error("Error:", err);
        res.status(500).send("Error checking username");
      } else {
        if (result.length > 0) {
          res.send({ exists: true });
        } else {
          res.send({ exists: false });
        }
      }
    });
  });
  

// API endpoint to submit the form data
app.post("/api/submit", (req, res) => {
  const id = req.body.id;
  const username = req.body.username;
  const password = req.body.password;
  const first_name = req.body.first_name;
  const last_name = req.body.last_name;
  const birth_date = req.body.birth_date;
  const contact_number = req.body.contact_number;
  const address = req.body.address;

  con.query(
    "insert into users values(?,?,?,?,?,?,?,?)",
    [
      id,
      username,
      password,
      first_name,
      last_name,
      birth_date,
      address,
      contact_number
      
    ],
    (err, result) => {
      if (err) {
        console.log(err);
      } else {
        res.send("data posted");
      }
    }
  );
});

//api for username and password matching 
app.get("/api/user", (req, res) => {
    const { username } = req.query;
  
    // Query the database to find the user information based on the provided username
    const query = `SELECT * FROM users WHERE username = '${username}'`;
  
    con.query(query, (err, results) => {
      if (err) {
        console.error("Error querying the database: ", err);
        res.status(500).json({ error: "Database error" });
        return;
      }
  
      // Check if the user with the provided username exists
      if (results.length > 0) {
        const user = results[0];
        // Return the user information as the response
        res.json(user);
      } else {
        // Return an empty response or appropriate error message if the user is not found
        res.status(404).json({ error: "User not found" });
      }
    });
  });

app.listen(5000, (err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("on port 5000");
  }
});
